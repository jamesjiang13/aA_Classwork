import React from 'react';
import TodoList from "./todos/todo_list_container"

const App = () => {
  return (
    <TodoList />
  )
}

export default App;